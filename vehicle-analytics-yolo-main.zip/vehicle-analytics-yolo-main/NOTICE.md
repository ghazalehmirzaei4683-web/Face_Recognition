# Source notice

This repository contains selected files from the Ultralytics project at commit:

`03d380d730aa0d180e6ae756404eaa218fd93b5d`

Upstream repository: https://github.com/ultralytics/ultralytics

The Analytics contribution in that revision was authored by Muhammad Rizwan Munawar with acknowledged co-authors in the upstream commit history. The included source remains subject to the GNU Affero General Public License v3.0 and retains its upstream copyright and license notices.

