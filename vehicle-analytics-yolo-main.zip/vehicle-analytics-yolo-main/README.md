# Vehicle Analytics with Ultralytics YOLO

Computer-vision components for vehicle detection, persistent tracking, multi-zone occupancy counting, directional entry/exit counting, traffic heatmaps, approximate speed estimation, and chart-based analytics.

## Capabilities

- Detect and track vehicles across video frames with Ultralytics YOLO.
- Count current vehicle occupancy inside multiple polygonal zones.
- Count directional entries and exits across a line or polygon boundary.
- Accumulate traffic-density heatmaps with configurable OpenCV color maps.
- Produce line, bar, and pie-chart visualizations from tracking and class-count data.
- Save annotated frames and analytical plots as video outputs.

## Repository contents

```text
docs/en/guides/analytics.md
examples/YOLOv8-Region-Counter/yolov8_region_counter.py
ultralytics/solutions/analytics.py
ultralytics/solutions/heatmap.py
ultralytics/solutions/object_counter.py
ultralytics/solutions/speed_estimation.py
```

The source snapshot corresponds to Ultralytics commit `03d380d730aa0d180e6ae756404eaa218fd93b5d`, where the original Analytics plotting implementation was introduced. The related modules are preserved at the same revision to keep their APIs consistent.

## Processing workflow

1. Read frames from a video or camera stream with OpenCV.
2. Detect and track objects with a YOLO model and persistent track IDs.
3. Associate each tracked object's center point with configured lines or polygonal regions.
4. Update occupancy, entry/exit, heatmap, and approximate-speed state.
5. Render annotated video and analytical charts.

## Running the region-counting example

Use a Python environment compatible with the historical Ultralytics 8.2.20 API.

```bash
python -m venv .venv
python -m pip install -r requirements.txt
python examples/YOLOv8-Region-Counter/yolov8_region_counter.py \
  --source path/to/traffic-video.mp4 \
  --weights yolov8n.pt \
  --save-img
```

Model weights are downloaded by Ultralytics when the selected model is first used. Input videos and generated outputs are intentionally excluded from version control.

## Accuracy note

The historical speed-estimation component calculates image-space displacement over elapsed time. It does not perform camera calibration, perspective correction, or a validated conversion from pixels to physical distance. Treat the displayed speed as an approximation. A production deployment should use a calibrated ground-plane transform or an external distance reference.

## License and attribution

The included Ultralytics source is provided under the GNU Affero General Public License v3.0. The source files retain their original notices. See `LICENSE` and `NOTICE.md` before modifying, deploying, or redistributing the code.

